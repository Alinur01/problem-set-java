public class KgAnthem {
    public static void main(String[] args) {
        System.out.println(">>>\n" +
                "White-capped rocky cliffs and steppes\n" +
                "Are equal to the soul of our people.\n" +
                "For countless centuries, our fathers\n" +
                "Have lived in and kept the Ala-Too.\n" +
                "\n" +
                "March forward, Kyrgyz people,\n" +
                "On the way to freedom!\n" +
                "Prosperity and progress,\n" +
                "Your own fate is in your hands!\n" +
                "\n" +
                ">>> ");
    }
}
