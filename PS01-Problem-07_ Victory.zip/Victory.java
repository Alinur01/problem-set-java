public class Victory {
    public static void main(String[] args) {
        System.out.println("//////////////////////\n" +
                "|| Victory is mine! ||\n" +
                "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
    }
}