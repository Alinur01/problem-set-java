public class MuchBetter {
    public static void main(String[] args) {
        System.out.printf("A \"quoted\" String is\n" +
                "'much' better if you learn\n" +
                "the rules of \"escape sequences.\"\n" +
                "Also, \"\" represents an empty String.\n" +
                "Don't forget: use \\\" instead of \" !\n" +
                "'' is not the same as \"");
    }
}