public class Hello {
    public static void main(String[] args) {
        System.out.println("public class Hello {\n" +
                "    public static void main(String[] args) {\n" +
                "        System.out.println(\"Hello, world!\");\n" +
                "    }\n" +
                "}");
    }
}