public class WellFormed {
    public static void main(String[] args) {
        System.out.printf("A well-formed Java program has\n" +
                "a main method with { and }\n" +
                "braces.\n" +
                "\n" +
                "A System.out.println statement\n" +
                "has ( and ) and usually a\n" +
                "String that starts and ends\n" +
                "with a \" character.\n" +
                "(But we type \\\" instead!)");
    }
}
